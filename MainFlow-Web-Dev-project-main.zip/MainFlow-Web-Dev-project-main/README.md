above files contain task 1 and task 2 of web development mainflow internship
